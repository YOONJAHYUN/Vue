<template>
  <div>
    <h1>App Child</h1>
    <input type="text" v-model="childData" />
    <p>parentData : {{ parentData }}</p>
    <p>childData : {{ childData }}</p>
  </div>
</template>

<script>
export default {
  name: "AppChild",
  data() {
    return {
      childData: "",
    };
  },
  props: {
    parentData: String,
  },
};
</script>

<style></style>
