<template>
  <div>
    <h1>App Parent</h1>
    <input type="text" v-model="parentData" />
    <p>AppData : {{ appData }}</p>
    <p>parentData : {{ parentData }}</p>
    <AppChild :parent-data="parentData" />
  </div>
</template>

<script>
import AppChild from "./AppChild.vue";

export default {
  name: "AppParent",
  props: {
    appData: String,
  },
  data() {
    return {
      parentData: "",
    };
  },
  components: {
    AppChild,
  },
};
</script>

<style></style>
